# dialogflow-aws-lambda
Dialogflow fulfillment webhook with ExpressJs on AWS Lambda

```bash
rm -rf ./dialogflow-webhook.zip && zip -r dialogflow-webhook.zip *
```